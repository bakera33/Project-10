Tutorial: https://www.youtube.com/watch?v=wPElVpR1rwA

1. Decomposition: In building a weather application, the app had to be broken
down into many parts.
    -Label info you want displayed using html
    -Style how the app should look
    -In JavaScript, fist locate the time zone of your location that you want
    displayed, set the API to receive info.
    -Grab weather information from API and display it on the app for your location
    -Using skycons, display the weather visually using skycons.js code and
    display it based on the data received by the API

2. Pattern Recognition: Some patterns that I dealt with were basically just Fetching
information and displaying it over and over again. Overall there weren't many
irregularities or trends, but just getting data from a source, and displaying
it in the app in different areas was a cool trend/pattern that I found was
interesting.

3. Abstraction: There are three parts of the application that are important for
a basic weather app. Location, temperature, and description of the weather. So
all three of these aspects are displayed and without one of them, a user would
be left wondering what a certain aspect of the weather is; for example, if
description was left out, the user would be wondering "is it 50 degrees and
sunny or 50 degrees and rainy so what should I wear?"
-A part that could be potentially ignored but is visually appealing and helpful
is the weather icon display. This shows the user what the weather is like which
is visually helpful, but could be left out since the weather description is written
out on the page as well. (Showing vs. telling basically)

4. Algorithm Design: The problem that needed to be solved was allowing a user
to have the app find their location, but it was seemingly not possible with
localhost:3000. A step by step process to fix this problem was to one, find out
why it couldn't locate them, two, find a solution, and three, implement the solution.
First, I'm not sure exactly why, but the app wouldn't find locations using the API
on localhost:3000. Next, a link was needed to be found to Proxy the API to allow
it to be used in localhost:3000, and finally, a line of code was added in JavaScript
that fixed the issue (  const proxy = `http://cors-anywhere.herokuapp.com/`;)
